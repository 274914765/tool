CGDB
====

CGDB is a very lightweight console frontend to the GNU debugger.  It provides
a split screen interface showing the GDB session below and the program's
source code above.  The interface is modelled after vim's, so vim users should
feel right at home using it.

Screenshot, downloads, and documentation are available from the home page:
http://cgdb.github.com/

Official source releases are available here:
http://cgdb.me/files
