#ifndef __USAGE_H__
#define __USAGE_H__

/**
 * This will generate the usage message for CGDB.
 */
void usage(void);

#endif /* __USAGE_H__ */
